import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-rules-mangement',
  templateUrl: './payment-rules-mangement.component.html',
  styleUrls: ['./payment-rules-mangement.component.css']
})
export class PaymentRulesMangementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
