import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-designation-details',
  templateUrl: './employee-designation-details.component.html',
  styleUrls: ['./employee-designation-details.component.css']
})
export class EmployeeDesignationDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
